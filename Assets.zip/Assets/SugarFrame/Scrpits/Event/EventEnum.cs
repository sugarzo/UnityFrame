﻿using Sirenix.OdinInspector;

public enum EventEnum
{ 
    [LabelText("游戏状态改变")]
    GameStatusChange,
    [LabelText("开始加载游戏")]
    GameLoad,
    [LabelText("开始保存游戏")]
    GameSave,
}
