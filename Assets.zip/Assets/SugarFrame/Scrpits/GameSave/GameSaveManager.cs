﻿using Sirenix.OdinInspector;
using UnityEngine;

namespace SugarFrame.GameSave
{
    public class GameSave
    {
        public string slotKey = "Save0";
        public string version = "1.0";
    }

    public class GameSaveManager : SingletonMono<GameSaveManager>
    {
        private GameSave GameSaveInstance;

        public string slotKey = "Save0";

        protected override void Awake()
        {
            base.Awake();
            GameSaveInstance = new GameSave();
        }

        public static GameSave GetGameSave()
        {
            return Instance.GameSaveInstance;
        }

        [Button,ButtonGroup]
        public static void SaveGameToSlot()
        {
            Debug.Log("存储卡槽存档 " + Instance.slotKey);

            EventManager.EmitEvent(EventEnum.GameSave.ToString());
            GetGameSave().slotKey = Instance.slotKey;
            var gs = GetGameSave();
            SaveData("GameSave",gs);
        }
        [Button, ButtonGroup]
        public static void LoadGameFromSlot()
        {
            Debug.Log("读取卡槽存档 " + Instance.slotKey);

            LoadData("GameSave",out Instance.GameSaveInstance);
            EventManager.EmitEvent(EventEnum.GameLoad.ToString());
        }

        public static void SaveData<T>(string saveKey,T data)
        {
            Debug.Log(saveKey + " 保存");
            ES3.Save(Instance.slotKey + "@" + saveKey,data);
        }
        public static void LoadData<T>(string saveKey,out T data)
        {
            Debug.Log(saveKey + " 读取");
            data = (T)ES3.Load(Instance.slotKey + "@" + saveKey);
        }
    }

}
