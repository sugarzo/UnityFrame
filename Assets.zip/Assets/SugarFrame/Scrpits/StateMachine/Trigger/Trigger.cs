﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

namespace SugarFrame.StateMachine
{
    [AddComponentMenu("Sugarzo触发器/Trigger")]
    public class Trigger : BaseTrigger
    {
    }
}


