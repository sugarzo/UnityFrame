﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;
using SugarFrame.GameStatus;

namespace SugarFrame.StateMachine
{
    [System.Serializable]
    public class Status
    {
        public StatusData config;

        [ValueDropdown(nameof(ValueDropID))]
        public string id;
        [ValueDropdown(nameof(ValueDropValue))]
        public string value;

        public List<string> ValueDropID()
        {
            if (config)
                return config.ValueDropID();
            return null;
        }
        public List<string> ValueDropValue()
        {
            if (config)
                return config.ValueDropValue(id);
            return null;
        }
        [LabelText("条件为真/假")]
        public bool isTrue = true;
    }

    [AddComponentMenu("Sugarzo触发器/游戏状态触发器")]
    public class StatusTrigger : BaseTrigger
    {
        public List<Status> status = new List<Status>();

        public override void Execute()
        {
            if (IsState())
                base.Execute();
        }

        public override void RegisterSaveTypeEvent()
        {
            base.RegisterSaveTypeEvent();
            
            if(status.Count > 0)
                EventManager.StartListening(EventEnum.GameStatusChange.ToString(), Execute);
        }
        public override void DeleteSaveTypeEvent()
        {
            base.DeleteSaveTypeEvent();

            EventManager.StopListening(EventEnum.GameStatusChange.ToString(), Execute);
        }

        private bool IsState()
        {
            foreach (var statu in status)
            {
                if (StatusManager.IsStatus(statu.config,statu.id,statu.value) != statu.isTrue)
                    return false;
            }
            return true;
        }
    }
}


