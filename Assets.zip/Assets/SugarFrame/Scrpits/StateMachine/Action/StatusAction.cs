﻿using Sirenix.OdinInspector;
using SugarFrame.GameStatus;
using System.Collections.Generic;
using UnityEngine;


namespace SugarFrame.StateMachine
{
    public class StatusAction : BaseAction
    {
        [Header("设置游戏状态")]
        public List<Status> status = new List<Status>();

        public override void RunningLogic()
        {
            foreach(var sta in status)
            {
                StatusManager.SetStatus(sta.config, sta.id, sta.value);
            }

            RunOver();
        }

        [System.Serializable]
        public class Status
        {
            public StatusData config;

            [ValueDropdown(nameof(ValueDropID))]
            public string id;
            [ValueDropdown(nameof(ValueDropValue))]
            public string value;

            public List<string> ValueDropID()
            {
                if (config)
                    return config.ValueDropID();
                return null;
            }
            public List<string> ValueDropValue()
            {
                if (config)
                    return config.ValueDropValue(id);
                return null;
            }
        }
    }

}