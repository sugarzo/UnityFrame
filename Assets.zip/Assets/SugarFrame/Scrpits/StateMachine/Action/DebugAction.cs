﻿using UnityEngine;


namespace SugarFrame.StateMachine
{
    public class DebugAction : BaseAction
    {
        [Header("Debug Action")]
        public string content;

        public override void RunningLogic()
        {
            Debug.Log(content);

            RunOver();
        }
    }

}