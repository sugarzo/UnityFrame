﻿using UnityEngine;
using UnityEngine.Events;

namespace SugarFrame.StateMachine
{
    public class UnityEventAction : BaseAction
    {
        [Header("UnityEventAction Action")]
        public UnityEvent unityEvent;

        public override void RunningLogic()
        {
            unityEvent?.Invoke();

            RunOver();
        }
    }

}