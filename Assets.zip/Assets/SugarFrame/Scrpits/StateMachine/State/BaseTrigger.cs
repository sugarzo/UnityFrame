﻿using System.Collections;
using UnityEngine;
using Sirenix.OdinInspector;

namespace SugarFrame.StateMachine
{
    public enum ExecutePeriod
    {
        None,
        Awake,
        Enable,
        Start,
        Update,
        DisEnable,
        Destroy,
    }

    public interface ITriggerEvent
    {
        void RegisterSaveTypeEvent();
        void DeleteSaveTypeEvent();
    }

    [RequireComponent(typeof(ActionControl))]
    public abstract class BaseTrigger : MonoState,ITriggerEvent
    {
        private ActionControl thisAction;
        [LabelText("生命周期执行")]
        public ExecutePeriod executePeriod = ExecutePeriod.None;

        //(可选)在子类中实现下面两个方法
        public virtual void RegisterSaveTypeEvent()
        {
            //EventManager.StartListening("");
        }
        public virtual void DeleteSaveTypeEvent()
        {
            //EventManager.StopListening("");
        }

        [Button]
        public override void Execute()
        {
            if (state == EState.Enter || state == EState.Running)
                return;

            base.Execute();
        }

        public override void OnEnter()
        {
            thisAction.StartAction();

            base.OnEnter();
        }

        protected virtual void Awake()
        {
            thisAction = GetComponent<ActionControl>();
            thisAction.connectTrigger = this;

            if (executePeriod == ExecutePeriod.Awake)
                Execute();
        }

        protected virtual void OnEnable()
        {
            if (executePeriod == ExecutePeriod.Enable)
                Execute();

            RegisterSaveTypeEvent();
        }

        protected virtual void Start()
        {
            if (executePeriod == ExecutePeriod.Start)
                Execute();

            //使用协程模拟update，优化不选择ExecutePeriod.Update时的性能
            if (executePeriod == ExecutePeriod.Update)
                StartCoroutine(IEUpdate());
        }

        protected virtual IEnumerator IEUpdate()
        {
            while(true)
            {
                yield return null;
                Execute();
            }
        }

        protected virtual void OnDisable()
        {
            if (executePeriod == ExecutePeriod.DisEnable)
                Execute();

            DeleteSaveTypeEvent();
        }

        protected virtual void OnDestroy()
        {
            if (executePeriod == ExecutePeriod.Destroy)
                Execute();
        }
    }
}


