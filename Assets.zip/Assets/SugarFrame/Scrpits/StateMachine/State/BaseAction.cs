﻿using UnityEngine;

namespace SugarFrame.StateMachine
{
    public abstract class BaseAction : State
    {
        [HideInInspector]
        public ActionControl parentNode;

        public virtual void RunningLogic()
        {
            //在派生类中填写逻辑

            RunOver();
        }

        public virtual void RunOver()
        {
            TransitionState(EState.Exit);
        }

        public override void OnRunning()
        {
            //base.OnRunning();

            RunningLogic();
        }

        public override void OnExit()
        {
            //回调ActionCotrol
            if(parentNode)
            {
                int index = parentNode.actionsList.FindIndex((x) => x.Equals(this));
                
                if(index < parentNode.actionsList.Count - 1)
                {
                    //如果还有Action则执行
                    parentNode.actionsList[index + 1].Execute();
                }
                else
                {
                    //切换Trigger状态
                    if (parentNode.connectTrigger)
                        parentNode.connectTrigger.OnExit();
                }

            }
            base.OnExit();
        }
    }
}


