﻿using System.Collections.Generic;
using Sirenix.OdinInspector;
using System;
using System.Linq;
using UnityEngine;
using Sirenix.Serialization;

namespace SugarFrame.StateMachine
{
    public class ActionControl : SerializedMonoBehaviour
    {
        [HideInInspector]
        public BaseTrigger connectTrigger;
        [ShowInInspector]
        [TypeFilter(nameof(GetActionList))]
        public List<BaseAction> actionsList = new List<BaseAction>();

        private void Awake()
        {
            foreach(var act in actionsList)
            {
                act.parentNode = this;
            }
        }
        public void StartAction()
        {
            if (actionsList.Count == 0)
                return;

            actionsList[0].Execute();
        }

        private IEnumerable<Type> GetActionList()
        {
            var q = typeof(BaseAction).Assembly.GetTypes()
                .Where(x => !x.IsAbstract)
                .Where(x => !x.IsGenericTypeDefinition)
                .Where(x => typeof(BaseAction).IsAssignableFrom(x));

            return q;
        }

        private void OnValidate()
        {
            foreach (var act in actionsList)
            {
                act.parentNode = this;
            }
        }
    }
}
