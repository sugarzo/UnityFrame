using UnityEngine;
using Sirenix.OdinInspector;

namespace SugarFrame.StateMachine
{
    public enum EState
    {
        [LabelText("δִ��")]
        None,
        [LabelText("���ڽ���")]
        Enter,
        [LabelText("����ִ��")]
        Running,
        [LabelText("�����˳�")]
        Exit,
        [LabelText("ִ�����")]
        Finish,
    }
    public interface IStateEvent
    {
        void Execute();
        void OnEnter();
        void OnRunning();
        void OnExit();
    }


    public class State : IStateEvent
    {
        [SerializeField, ReadOnly]
        protected EState state;

        protected void TransitionState(EState _state)
        {
            state = _state;

            switch (_state)
            {
                case EState.Enter:
                    OnEnter();
                    break;
                case EState.Running:
                    OnRunning();
                    break;
                case EState.Exit:
                    OnExit();
                    break;
            }
        }
        public virtual void Execute()
        {
            TransitionState(EState.Enter);
        }
        public virtual void OnEnter()
        {
            TransitionState(EState.Running);
        }
        public virtual void OnRunning()
        {
            TransitionState(EState.Exit);
        }
        public virtual void OnExit()
        {
            TransitionState(EState.Finish);
        }
    }

    public abstract class MonoState : MonoBehaviour, IStateEvent
    {
        [SerializeField,ReadOnly]
        protected EState state;
        protected void TransitionState(EState _state)
        {
            state = _state;

            switch (state)
            {
                case EState.Enter:
                    OnEnter();
                    break;
                case EState.Running:
                    OnRunning();
                    break;
                case EState.Exit:
                    OnExit();
                    break;
            }
        }

        public virtual void Execute()
        {
            TransitionState(EState.Enter);
        }
        public virtual void OnEnter()
        {
            TransitionState(EState.Running);
        }
        public virtual void OnRunning()
        {
            TransitionState(EState.Exit);
        }
        public virtual void OnExit()
        {
            TransitionState(EState.Finish);
        }
    }
}


