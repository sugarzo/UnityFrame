﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

namespace SugarFrame.GameStatus
{
    public interface IStatusCheck<TKey,TValue>
    {
        List<TKey> SelectID();
        List<TValue> SelectValue(TKey ID);
    }
    public abstract class StatusData : ScriptableObject
    {
        public void OnEnable()
        {
            key = this.GetType().ToString() + "-" + name;
        }
        [Header("请保证key值唯一")]
        public string key;

        public abstract List<string> ValueDropID();
        public abstract List<string> ValueDropValue(string id);
    }

    public class StatusData<TKey, TValue> : StatusData, IStatusCheck<TKey, TValue>
    {
        [Header("备注"),TextArea]
        public string content;

        [Space]
        public List<Data> datas;

        [Serializable]
        public class Data
        {
            public TKey ID;
            public List<TValue> Values;
        }

        public virtual List<TKey> SelectID()
        {
            List<TKey> retList = new List<TKey>();
            foreach(var id in datas)
            {
                retList.Add(id.ID);
            }
            return retList;
        }
        public virtual List<TValue> SelectValue(TKey ID)
        {
            List<TValue> retList = new List<TValue>();

            var selectData = datas.Find(x => x.ID.Equals(ID));
            if (selectData != null)
                retList = selectData.Values;

            return retList;
        }

        public override List<string> ValueDropID()
        {
            List<string> retList = new List<string>();
            foreach (var id in datas)
            {
                retList.Add(id.ID.ToString());
            }
            return retList;
        }

        public override List<string> ValueDropValue(string id)
        {
            List<string> retList = new List<string>();

            var selectData = datas.Find(x => x.ID.ToString() == id.ToString());
            if (selectData != null)
            {
                foreach(var str in selectData.Values)
                    retList.Add(str.ToString());
            }
                

            return retList;
        }
    }
}
