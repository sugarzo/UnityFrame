﻿using System;
using System.Collections.Generic;
using UnityEngine;
using SugarFrame.GameSave;

namespace SugarFrame.GameStatus
{
    public interface IStatusSave
    {
        void LoadData();
        void SaveData();
    }
    public interface IStatusCheck
    {
        bool IsStatus(string _data, string _id, string _value);
        void SetStatus(string _data, string _id, string _value);
    }


    public static class StatusManager
    {
        public static Dictionary<Type,IStatusCheck> managerInstances = new Dictionary<Type, IStatusCheck>();

        public static bool IsStatus(StatusData data, string ID, string value)
        {
            if (managerInstances.ContainsKey(data.GetType()))
                return managerInstances[data.GetType()].IsStatus(data.key, ID, value);

            Debug.LogError("找不到关于 " + data.name + " 的管理类实例");
            return false;
        }
        public static void SetStatus(StatusData data, string ID, string value)
        {
            if (managerInstances.ContainsKey(data.GetType()))
            {
                Debug.Log("切换游戏状态 " + ID + " -> " + value);
                managerInstances[data.GetType()].SetStatus(data.key, ID, value);
                EventManager.EmitEvent(EventEnum.GameStatusChange.ToString());
            }
        }
    }


    public class StatusManager<TData,TKey, TValue> : MonoBehaviour,IStatusSave, IStatusCheck where TData : StatusData<TKey, TValue>
    {

        public virtual bool IsStatus(string _data, string _id, string _value)
        {
            if(configData.ContainsKey(_data))
                if (configData[_data].ContainsKey(_id))
                    return configData[_data][_id].Equals(_value);

            Debug.LogError("找不到关于 " + _id + " 的数据类型");
            return false;
        }

        public virtual void SetStatus(string _data, string _id, string _value)
        {
            if (configData.ContainsKey(_data))
                if (configData[_data].ContainsKey(_id))
                {
                    configData[_data][_id] = _value;
                }
                else
                    Debug.LogError("找不到关于 " + _id + " 的数据类型");
            else
                Debug.LogError("找不到关于 " + _id + " 的数据类型");

            return;
        }

        public List<TData> configs;
        protected Dictionary<string, Dictionary<string, string>> configData;

        protected virtual void Awake()
        {
            InitData();
            RegisterStatic(); 
            RegisterSave();
        }

        //初始化字典数据
        protected virtual void InitData()
        {
            configData = new Dictionary<string, Dictionary<string, string>>();
            foreach(var config in configs)
            {
                configData.Add(config.key, new Dictionary<string, string>());
                foreach(var cData in config.datas)
                {
                    configData[config.key].Add(cData.ID.ToString(), string.Empty);
                }
            }
        }
        //注册静态数据
        protected virtual void RegisterStatic()
        {
            StatusManager.managerInstances.Add(typeof(TData), this);
        }
        //注册存档事件监听数据
        protected virtual void RegisterSave()
        {
            EventManager.StartListening(EventEnum.GameSave.ToString(), SaveData);
            EventManager.StartListening(EventEnum.GameLoad.ToString(), LoadData);
        }


        public void LoadData()
        {
            GameSaveManager.LoadData(this.GetType().ToString(), out configData);
        }

        public void SaveData()
        {
            GameSaveManager.SaveData(this.GetType().ToString(), configData);
        }

        [Sirenix.OdinInspector.Button]
        public void DebugAllStatus()
        {
            foreach (var data in configData)
            {
                foreach (var cData in data.Value)
                {
                    Debug.Log(cData.Key + " " + cData.Value);
                }
            }
        }
    }

}
