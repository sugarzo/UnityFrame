﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;
using UnityEditor;

namespace SugarFrame.GameStatus
{
    [CreateAssetMenu(menuName = "新建状态/游戏状态")]
    public class GameStatusData : StatusData<string, string>
    {
        
    }

}
