﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SugarFrame.GameStatus
{
    public class GameStatusManager : StatusManager<GameStatusData,string,string>
    {

    }
}
